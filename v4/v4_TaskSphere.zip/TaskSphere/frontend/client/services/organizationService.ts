import { useAuth } from '../contexts/AuthContext';

export interface OrgNode {
  id: string;
  name: string;
  role: string;
  email: string;
  department?: string;
  isCurrentUser?: boolean;
  children?: OrgNode[];
}

export const organizationService = {
  buildOrgHierarchy: async (currentUser: any): Promise<OrgNode> => {
    // Mock organizational data - replace with actual API call
    const orgData: OrgNode = {
      id: "1",
      name: "Sarah Johnson",
      role: "CEO",
      email: "sarah.johnson@company.com",
      department: "Executive",
      children: [
        {
          id: "2",
          name: "Michael Chen",
          role: "VP Engineering",
          email: "michael.chen@company.com",
          department: "Engineering",
          children: [
            {
              id: "3",
              name: "Emily Rodriguez",
              role: "Engineering Manager",
              email: "emily.rodriguez@company.com",
              department: "Engineering",
              children: [
                {
                  id: "4",
                  name: "David Kim",
                  role: "Team Lead",
                  email: "david.kim@company.com",
                  department: "Engineering",
                  children: [
                    {
                      id: "5",
                      name: currentUser?.name || "John Doe",
                      role: currentUser?.role || "Team Member",
                      email: currentUser?.email || "john.doe@company.com",
                      department: "Engineering",
                      isCurrentUser: true
                    },
                    {
                      id: "6",
                      name: "Alice Wilson",
                      role: "Senior Developer",
                      email: "alice.wilson@company.com",
                      department: "Engineering"
                    },
                    {
                      id: "7",
                      name: "Bob Thompson",
                      role: "Developer",
                      email: "bob.thompson@company.com",
                      department: "Engineering"
                    }
                  ]
                }
              ]
            },
            {
              id: "8",
              name: "Lisa Park",
              role: "QA Manager",
              email: "lisa.park@company.com",
              department: "Quality Assurance",
              children: [
                {
                  id: "9",
                  name: "Tom Davis",
                  role: "QA Lead",
                  email: "tom.davis@company.com",
                  department: "Quality Assurance"
                }
              ]
            }
          ]
        },
        {
          id: "10",
          name: "Jennifer Martinez",
          role: "VP Marketing",
          email: "jennifer.martinez@company.com",
          department: "Marketing",
          children: [
            {
              id: "11",
              name: "Chris Anderson",
              role: "Marketing Manager",
              email: "chris.anderson@company.com",
              department: "Marketing"
            }
          ]
        }
      ]
    };

    // Adjust hierarchy based on current user's role
    if (currentUser?.role === 'manager') {
      // If user is a manager, show them higher in the hierarchy
      return {
        ...orgData,
        children: orgData.children?.map(vp => ({
          ...vp,
          children: vp.children?.map(manager => 
            manager.name === currentUser.name 
              ? { ...manager, isCurrentUser: true }
              : manager
          )
        }))
      };
    }

    if (currentUser?.role === 'team-leader') {
      // If user is a team leader, show them in the team lead position
      return {
        ...orgData,
        children: orgData.children?.map(vp => ({
          ...vp,
          children: vp.children?.map(manager => ({
            ...manager,
            children: manager.children?.map(lead =>
              lead.name === currentUser.name
                ? { ...lead, isCurrentUser: true }
                : lead
            )
          }))
        }))
      };
    }

    if (currentUser?.role === 'admin') {
      // If user is admin/CEO, show them at the top
      return {
        ...orgData,
        name: currentUser.name,
        email: currentUser.email,
        isCurrentUser: true
      };
    }

    return orgData;
  }
};