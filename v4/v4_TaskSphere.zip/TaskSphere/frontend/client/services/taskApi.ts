const API_BASE_URL = 'http://localhost:8087/api/tasks';

export interface TaskDTO {
  id?: number;
  title: string;
  description: string;
  assignedTo: number;
  priority: string;
  status: string;
  deadline: string;
  progress?: number;
}

// LocalStorage fallback
const getLocalTasks = (): any[] => {
  const stored = localStorage.getItem('tasks');
  return stored ? JSON.parse(stored) : [];
};

const saveLocalTasks = (tasks: any[]) => {
  localStorage.setItem('tasks', JSON.stringify(tasks));
};

const fetchWithFallback = async (url: string, options?: RequestInit) => {
  const token = localStorage.getItem('authToken');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options?.headers,
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  const response = await fetch(url, {
    ...options,
    mode: 'cors',
    headers,
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    return await response.json();
  }
  return null;
};

export const taskApi = {
  getAllTasks: async (assignedTo?: number, status?: string, priority?: string) => {
    const params = new URLSearchParams();
    if (assignedTo) params.append('assignedTo', assignedTo.toString());
    if (status && status !== 'all') params.append('status', status);
    if (priority && priority !== 'all') params.append('priority', priority);
    
    return await fetchWithFallback(`${API_BASE_URL}?${params}`);
  },

  getTaskById: async (id: number) => {
    const result = await fetchWithFallback(`${API_BASE_URL}/${id}`);
    if (result.success) return result.data;
    
    const tasks = getLocalTasks();
    return tasks.find((t: any) => t.id === id);
  },

  createTask: async (task: TaskDTO) => {
    const result = await fetchWithFallback(API_BASE_URL, {
      method: 'POST',
      body: JSON.stringify(task),
    });
    if (result.success) return result.data;
    
    // Fallback to localStorage
    const tasks = getLocalTasks();
    const newTask = { ...task, id: Date.now() };
    tasks.push(newTask);
    saveLocalTasks(tasks);
    return newTask;
  },

  updateTask: async (id: number, task: TaskDTO) => {
    const result = await fetchWithFallback(`${API_BASE_URL}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(task),
    });
    if (result.success) return result.data;
    
    // Fallback to localStorage
    const tasks = getLocalTasks();
    const index = tasks.findIndex((t: any) => t.id === id);
    if (index !== -1) {
      tasks[index] = { ...task, id };
      saveLocalTasks(tasks);
      return tasks[index];
    }
    return null;
  },

  deleteTask: async (id: number) => {
    const result = await fetchWithFallback(`${API_BASE_URL}/${id}`, { method: 'DELETE' });
    if (result.success) return;
    
    // Fallback to localStorage
    const tasks = getLocalTasks();
    const filtered = tasks.filter((t: any) => t.id !== id);
    saveLocalTasks(filtered);
  },

  reassignTask: async (id: number, newAssignee: string) => {
    const result = await fetchWithFallback(`${API_BASE_URL}/${id}/reassign?newAssignee=${newAssignee}`, {
      method: 'PUT',
    });
    if (result.success) return result.data;
    
    // Fallback to localStorage
    const tasks = getLocalTasks();
    const task = tasks.find((t: any) => t.id === id);
    if (task) {
      task.assignedTo = parseInt(newAssignee);
      saveLocalTasks(tasks);
      return task;
    }
    return null;
  },

  addComment: async (id: number, comment: string) => {
    const result = await fetchWithFallback(`${API_BASE_URL}/${id}/comment?comment=${encodeURIComponent(comment)}`, {
      method: 'POST',
    });
    if (result.success) return result.data;
    return null;
  },

  getAnalytics: async () => {
    const result = await fetchWithFallback(`${API_BASE_URL}/analytics`);
    if (result.success) return result.data;
    return {};
  },

  getReminders: async () => {
    const result = await fetchWithFallback(`${API_BASE_URL}/reminders`);
    if (result.success) return result.data;
    return [];
  },
};
