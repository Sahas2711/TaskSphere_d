import axiosInstance from '../api/axiosConfig';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  jwtToken: string;
  userName: string;
  userId: number;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
  role: string;
  phoneNumber: string;
  gender: string;
}

export interface RegisterResponse {
  message: string;
  userId: number;
  userName: string;
}

export const authService = {
  login: async (credentials: LoginRequest): Promise<LoginResponse> => {
    const response = await axiosInstance.post('/auth/login', credentials);
    return response.data;
  },
  
  register: async (userData: RegisterRequest): Promise<RegisterResponse> => {
    const response = await axiosInstance.post('/api/users/register', userData);
    return response.data;
  },
};