import axiosInstance from './axiosConfig';

export interface User {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  bio?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserSettings {
  emailNotifications: boolean;
  pushNotifications: boolean;
  smsNotifications: boolean;
  weeklyDigest: boolean;
  twoFactorEnabled: boolean;
  sessionTimeout: number;
  theme: string;
  language: string;
}

export interface UpdateUserRequest {
  name?: string;
  phoneNumber?: string;
  gender?: string;
}

export interface UpdateSettingsRequest {
  emailNotifications?: boolean;
  pushNotifications?: boolean;
  smsNotifications?: boolean;
  weeklyDigest?: boolean;
  twoFactorEnabled?: boolean;
  sessionTimeout?: number;
  theme?: string;
  language?: string;
}

export const userApi = {
  getCurrentUser: async (): Promise<User> => {
    const response = await axiosInstance.get('/users/me');
    return response.data;
  },

  updateUser: async (data: UpdateUserRequest): Promise<User> => {
    const response = await axiosInstance.put('/users/update', data);
    return response.data;
  },

  getUserSettings: async (): Promise<UserSettings> => {
    const response = await axiosInstance.get('/users/me');
    return response.data;
  },

  updateUserSettings: async (data: UpdateSettingsRequest): Promise<UserSettings> => {
    const response = await axiosInstance.put('/users/me', data);
    return response.data;
  },

  changePassword: async (currentPassword: string, newPassword: string): Promise<void> => {
    await axiosInstance.put('/users/change-password', {
      currentPassword,
      newPassword
    });
  },

  deleteAccount: async (): Promise<void> => {
    await axiosInstance.delete('/users/me');
  }
};