import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { ProtectedRoute } from "./components/ProtectedRoute";
import MainLayout from "@/components/layout/MainLayout";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Workspace from "./pages/Workspace";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Tasks from "./pages/Tasks";
import Analytics from "./pages/Analytics";
import Notifications from "./pages/Notifications";
import TaskDetails from "./pages/TaskDetails";
import Teams from "./pages/Teams";
import Settings from "./pages/Settings";
import Profile from "./pages/Profile";
import Calendar from "./pages/Calendar";
import ForgotPassword from "./pages/ForgotPassword";
import ManagerDashboard from "./pages/ManagerDashboard";
import TeamLeaderDashboard from "./pages/Team_leader_Dashboard";
import MemberDashboard from "./pages/MemberDashboard";
import MemberTasks from "./pages/Member_tasks";

const queryClient = new QueryClient();

const App = () => {
  console.log('App component rendering');
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            
            {/* Admin Routes */}
            <Route path="/dashboard" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Dashboard />
              </ProtectedRoute>
            } />
            
            {/* Manager Routes */}
            <Route path="/manager-dashboard" element={
              <ProtectedRoute allowedRoles={['manager']}>
                <ManagerDashboard />
              </ProtectedRoute>
            } />
            <Route path="/manager-dashboard/team" element={
              <ProtectedRoute allowedRoles={['manager']}>
                <ManagerDashboard />
              </ProtectedRoute>
            } />
            
            {/* Team Leader Routes */}
            <Route path="/team-leader-dashboard" element={
              <ProtectedRoute allowedRoles={['team-leader']}>
                <TeamLeaderDashboard />
              </ProtectedRoute>
            } />
            
            {/* Member Routes */}
            <Route path="/member-dashboard" element={
              <ProtectedRoute allowedRoles={['team-member']}>
                <MemberDashboard />
              </ProtectedRoute>
            } />
            <Route path="/member-dashboard/tasks" element={
              <ProtectedRoute allowedRoles={['team-member']}>
                <MemberTasks />
              </ProtectedRoute>
            } />
            
            {/* Shared Routes */}
            <Route path="/dashboard/tasks" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader', 'team-member']}>
                <Tasks />
              </ProtectedRoute>
            } />
            <Route path="/dashboard/tasks/:id" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader', 'team-member']}>
                <TaskDetails />
              </ProtectedRoute>
            } />
            <Route path="/dashboard/teams" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader', 'team-member']}>
                <Teams />
              </ProtectedRoute>
            } />
            <Route path="/dashboard/calendar" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader', 'team-member']}>
                <Calendar />
              </ProtectedRoute>
            } />
            <Route path="/dashboard/analytics" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader']}>
                <Analytics />
              </ProtectedRoute>
            } />
            <Route path="/dashboard/notifications" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader', 'team-member']}>
                <Notifications />
              </ProtectedRoute>
            } />
            <Route path="/dashboard/settings" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader', 'team-member']}>
                <Settings />
              </ProtectedRoute>
            } />
            <Route path="/dashboard/profile" element={
              <ProtectedRoute allowedRoles={['admin', 'manager', 'team-leader', 'team-member']}>
                <Profile />
              </ProtectedRoute>
            } />
            <Route element={<MainLayout />}>
              <Route path="/" element={<Index />} />
              <Route path="/workspace" element={<Workspace />} />
              <Route path="*" element={<NotFound />} />
            </Route>
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

console.log('Starting React app');
const rootElement = document.getElementById("root");
console.log('Root element:', rootElement);

if (rootElement) {
  createRoot(rootElement).render(<App />);
} else {
  console.error('Root element not found!');
}
