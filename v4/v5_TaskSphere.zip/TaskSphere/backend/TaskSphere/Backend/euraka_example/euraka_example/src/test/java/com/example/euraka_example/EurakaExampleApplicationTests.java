package com.example.euraka_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurakaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
