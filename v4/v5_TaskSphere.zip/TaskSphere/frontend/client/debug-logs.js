// Debug Utility - Run in browser console after login attempt
console.log('=== API REQUEST LOGS ===');
console.log(sessionStorage.getItem('apiLogs'));

// Clear logs
// sessionStorage.removeItem('apiLogs');